import asyncio,json,pathlib,hashlib,subprocess,urllib.request,secrets
from playwright.async_api import async_playwright
P=pathlib.Path('/workspace/.acceptance/lingdoc-t16-closeout-20260927-01');D=P/'failure-boundaries';fixture=json.loads((D/'http-fixture.json').read_text());login=json.loads((D/'private-login.json').read_text());export=fixture['artifact'];responses=[]
assert fixture['database']=='lingdoc_fault_http_20261001_01'
assert export['id'].startswith('export-') and all(c in '0123456789abcdef' for c in export['id'][7:])

def corrupt():
 sql="UPDATE lingdoc_export_artifacts SET file_blob=set_byte(file_blob,0,get_byte(file_blob,0) # 1) WHERE id='"+export['id']+"';"
 args=['docker','compose','--project-name','lingdoc','--env-file','/workspace/.setup/lingdoc/state/services.env','-f','/workspace/.setup/lingdoc/compose.yaml','exec','-T','postgres','psql','-U','lingdoc','-d',fixture['database'],'-v','ON_ERROR_STOP=1','-c',sql]
 r=subprocess.run(args,check=True,capture_output=True,text=True);assert 'UPDATE 1' in r.stdout

def reexport():
 req=urllib.request.Request('http://127.0.0.1:8181/api/v1/lingdoc/projects/'+export['project_id']+'/releases/'+export['snapshot_id']+'/exports',headers={'Authorization':'Bearer '+login['token'],'X-Tenant-ID':str(login['active_tenant']['id']),'Idempotency-Key':'integrity-recover-'+secrets.token_hex(10),'Content-Type':'application/json'},data=b'{"format":"docx"}',method='POST')
 with urllib.request.urlopen(req) as r:assert r.status==202;obj=json.load(r)['data']
 assert obj['status']=='verified';return obj

async def main():
 async with async_playwright() as w:
  browser=await w.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);context=await browser.new_context(viewport={'width':1440,'height':1000},accept_downloads=True,record_video_dir=str(D/'browser-videos'),record_video_size={'width':1440,'height':1000});page=await context.new_page();errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:responses.append({'path':r.url.split('5174')[-1],'method':r.request.method,'status':r.status}) if '/api/v1/lingdoc/' in r.url else None)
  await page.goto('http://127.0.0.1:5174');await page.evaluate('d=>{for(const[k,v]of Object.entries({weknora_token:d.token,weknora_user:JSON.stringify(d.user),weknora_tenant:JSON.stringify(d.active_tenant),weknora_memberships:JSON.stringify(d.memberships),weknora_selected_tenant_id:String(d.active_tenant.id)}))localStorage.setItem(k,v)}',login)
  await page.goto('http://127.0.0.1:5174/platform/lingdoc');await page.wait_for_timeout(3000)
  if await page.get_by_text('跳过引导',exact=True).count():await page.get_by_text('跳过引导',exact=True).click()
  await page.get_by_text('T16 隔离文件损坏定向验收',exact=True).click();await page.get_by_role('button',name='下载 DOCX',exact=True).first.wait_for();await page.locator('.delivery').scroll_into_view_if_needed();await page.wait_for_timeout(2000)
  if await page.get_by_text('跳过引导',exact=True).count():await page.get_by_text('跳过引导',exact=True).click()
  await page.screenshot(path=str(D/'http-before-corruption.png'));await page.wait_for_timeout(1200)
  async with page.expect_download() as info:await page.get_by_role('button',name='下载 DOCX',exact=True).first.click()
  download=await info.value;f=D/'isolated-browser-before.docx';await download.save_as(str(f));assert hashlib.sha256(f.read_bytes()).hexdigest()==export['file_sha256']
  corrupt();await page.get_by_role('button',name='下载 DOCX',exact=True).first.click();await page.get_by_text('导出文件不可用或完整性校验失败，请重新导出。',exact=True).wait_for();await page.screenshot(path=str(D/'http-corrupt-file-refused.png'));await page.wait_for_timeout(2000)
  assert any(x['status']==422 and x['path'].endswith('/file') for x in responses)
  recovered=reexport();await page.reload();await page.wait_for_timeout(3000)
  if await page.get_by_text('跳过引导',exact=True).count():await page.get_by_text('跳过引导',exact=True).click()
  await page.get_by_text('T16 隔离文件损坏定向验收',exact=True).click();await page.get_by_role('button',name='下载 DOCX',exact=True).first.wait_for();await page.locator('.delivery').scroll_into_view_if_needed();await page.screenshot(path=str(D/'http-reexport-recovered.png'))
  async with page.expect_download() as info:await page.get_by_role('button',name='下载 DOCX',exact=True).first.click()
  download=await info.value;f=D/'isolated-browser-recovered.docx';await download.save_as(str(f));assert hashlib.sha256(f.read_bytes()).hexdigest()==recovered['file_sha256'];await page.wait_for_timeout(2000)
  video=page.video;await context.close();video_path=await video.path();await browser.close();assert not errors
  count=len(json.loads((P/'model-ledger.json.calls.json').read_text())['requests']);assert count==6
  (D/'http-browser-result.json').write_text(json.dumps({'passed':True,'database':fixture['database'],'actual_server':'server-mvp-integrity-final','actual_browser':'system Chromium','initial_download_hash':export['file_sha256'],'corrupt_download_status':422,'corrupt_download_bytes_not_exposed':True,'visible_reexport_instruction':True,'new_export_id':recovered['id'],'recovered_download_hash':recovered['file_sha256'],'responses':responses,'page_errors':errors,'video':video_path,'new_model_calls':0,'round_model_count_after':count,'scope':'Actual production DI/API/PostgreSQL/browser on isolated database; controlled persisted-byte corruption, source-free manual fixture; primary acceptance database untouched'},ensure_ascii=False,indent=2));print('Isolated production browser corrupted download rejection and reexport recovery PASS')
asyncio.run(main())
