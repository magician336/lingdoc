from pathlib import Path
import json,secrets,urllib.request,urllib.error,os,hashlib
P=Path('/workspace/.acceptance/lingdoc-t16-closeout-20260927-01');D=P/'failure-boundaries';events=[];token='';tenant=None
before=len(json.loads((P/'model-ledger.json.calls.json').read_text())['requests']);assert before==6

def private(name,obj):
 fd=os.open(D/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(obj,f)
def call(method,path,body=None,want=200):
 h={'Content-Type':'application/json','Idempotency-Key':'integrity-'+secrets.token_hex(12)}
 if token:h['Authorization']='Bearer '+token
 if tenant:h['X-Tenant-ID']=str(tenant)
 req=urllib.request.Request('http://127.0.0.1:8181/api/v1'+path,headers=h,method=method,data=json.dumps(body).encode() if body is not None else None)
 try:
  with urllib.request.urlopen(req,timeout=30) as r:status=r.status;b=r.read();ct=r.headers.get('Content-Type','')
 except urllib.error.HTTPError as r:status=r.code;b=r.read();ct=r.headers.get('Content-Type','')
 obj=json.loads(b) if 'json' in ct else b
 events.append({'method':method,'path':path,'status':status});(D/'http-events.json').write_text(json.dumps(events,indent=2))
 assert status==want,(path,status,obj.get('error') if isinstance(obj,dict) else 'binary')
 return obj.get('data',obj) if isinstance(obj,dict) else obj
account=json.loads((D/'private-account.json').read_text())
login=call('POST','/auth/login',{'email':account['email'],'password':account['password']});private('private-login.json',login);token=login['token'];tenant=login['active_tenant']['id']
project=call('POST','/lingdoc/projects',{'name':'T16 隔离文件损坏定向验收','template_id':'template-demo'},201);root='/lingdoc/projects/'+project['id']
call('PUT',root+'/spec',{'expected_spec_revision':0,'fields':{'research_subject':'隔离交付完整性验证','research_goal':'拒绝损坏文件，不改动主验收资料'}})
project=call('POST',root+'/activate',{'expected_spec_revision':1})
chapters=call('GET',root+'/chapters')
for chapter in chapters:
 version=call('POST',root+'/chapters/'+chapter['id']+'/versions',{'expected_chapter_version_id':None,'expected_spec_revision':1,'body_markdown':'隔离完整性验收人工正文。文件传输必须与已验证的 SHA256 一致。仅用于定向故障验证。','source_ids':[]},201)
 current=next(c for c in call('GET',root+'/chapters') if c['id']==chapter['id'])
 call('POST',root+'/chapters/'+chapter['id']+'/confirmations',{'expected_chapter_version_id':current['current_version_id'],'expected_spec_revision':1,'review_decisions':[]},201)
project=call('GET',root);snapshot=call('POST',root+'/releases',{'expected_project_version':project['project_version']},201)
artifact=call('POST',root+'/releases/'+snapshot['id']+'/exports',{'format':'docx'},202);assert artifact['status']=='verified'
file=call('GET',artifact['download_path'].removeprefix('/api/v1'));assert hashlib.sha256(file).hexdigest()==artifact['file_sha256'];(D/'isolated-original.docx').write_bytes(file)
(D/'http-fixture.json').write_text(json.dumps({'database':'lingdoc_fault_http_20261001_01','server_port':8181,'redis_db':15,'project':project,'artifact':artifact,'synthetic_manual_content':True,'real_provider_requests':0,'separate_from_primary_acceptance_identity':True},ensure_ascii=False,indent=2));print('Isolated production HTTP verified DOCX prepared; zero provider requests')
