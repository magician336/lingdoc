# LingDoc MVP 最新验收包

解压后先打开 [一次性验收入口](验收入口.html) 或 [全部16项集中清单](T01-T16-一次性验收.md)。

再读 [完整验收状态](MVP-完整验收现状-20261001.md) 和 [新增失败边界收尾](failure-boundaries/收尾记录.md)。

- [最新浏览器全链路录屏](full-chain/LingDoc-全链路浏览器验收.mp4)
- [集中人工审查清单](full-chain/验收收尾.md)
- [最新浏览器下载DOCX](full-chain/browser-current-model.docx)
- [真实模型候选与交付录屏](real-integration/LingDoc-真实模型验收演示.mp4)
- [损坏文件拒绝与恢复录屏](failure-boundaries/LingDoc-损坏文件拒绝与恢复.mp4)
- [真实模型DOCX](real-integration/real-model-delivery.docx)
- [真实模型两页PDF](real-integration/real-model-delivery.pdf)
- [来源撤权结果](real-integration/source-share-result.json)
- [隔离PostgreSQL故障测试](failure-boundaries/postgres-fault-tests-final.log)
- [实际浏览器损坏拒绝及恢复](failure-boundaries/http-browser-result.json)
- [未提交代码差异](real-integration/uncommitted-code.patch)
- [实际调用账本](model-ledger.json.calls.json)

待gong审查，不声称全部通过。真实模型链路、受控模型故障、隔离生产损坏注入及人工反馈的证据范围各自注明。模型累计6次，本轮新增0次；之前超出保守承诺1次的事实未更改。凭证不包含在包内。
