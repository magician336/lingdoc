from pathlib import Path
import json,zipfile,hashlib,subprocess,os,re,datetime
P=Path('/workspace/.acceptance/lingdoc-t16-closeout-20260927-01');R=Path('/workspace/lingdoc');target=P/'LingDoc-MVP-验收证据-20261001.zip'
with zipfile.ZipFile(target) as z:names=set(z.namelist())-{'MVP-验收包-manifest.json','INDEX.md'}
for f in list((P/'failure-boundaries').iterdir())+list((P/'full-chain').iterdir()):
 if f.is_file() and f.suffix in ['.json','.png','.docx','.pdf','.mp4','.md','.log','.py','.sh'] and 'private' not in f.name:names.add(f.relative_to(P).as_posix())
names.update({'验收入口.html','T01-T16-一次性验收.md'})
patch=subprocess.check_output(['git','diff','1c01f983c30440f8f9e103d202479045d991e81e','--binary','--','cmd','frontend','internal'],cwd=R)
for f in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).decode().split('\0'):
 if f.startswith('internal/'):
  result=subprocess.run(['git','diff','--no-index','--binary','/dev/null',f],cwd=R,stdout=subprocess.PIPE);assert result.returncode in [0,1];patch+=result.stdout
(P/'real-integration/uncommitted-code.patch').write_bytes(patch)
index='''# LingDoc MVP 最新验收包

解压后先打开 [一次性验收入口](验收入口.html) 或 [全部16项集中清单](T01-T16-一次性验收.md)。

再读 [完整验收状态](MVP-完整验收现状-20261001.md) 和 [新增失败边界收尾](failure-boundaries/收尾记录.md)。

- [最新浏览器全链路录屏](full-chain/LingDoc-全链路浏览器验收.mp4)
- [集中人工审查清单](full-chain/验收收尾.md)
- [最新浏览器下载DOCX](full-chain/browser-current-model.docx)
- [真实模型候选与交付录屏](real-integration/LingDoc-真实模型验收演示.mp4)
- [损坏文件拒绝与恢复录屏](failure-boundaries/LingDoc-损坏文件拒绝与恢复.mp4)
- [真实模型DOCX](real-integration/real-model-delivery.docx)
- [真实模型两页PDF](real-integration/real-model-delivery.pdf)
- [来源撤权结果](real-integration/source-share-result.json)
- [隔离PostgreSQL故障测试](failure-boundaries/postgres-fault-tests-final.log)
- [实际浏览器损坏拒绝及恢复](failure-boundaries/http-browser-result.json)
- [未提交代码差异](real-integration/uncommitted-code.patch)
- [实际调用账本](model-ledger.json.calls.json)

待gong审查，不声称全部通过。真实模型链路、受控模型故障、隔离生产损坏注入及人工反馈的证据范围各自注明。模型累计6次，本轮新增0次；之前超出保守承诺1次的事实未更改。凭证不包含在包内。
'''
(P/'INDEX.md').write_text(index);names.add('INDEX.md')
secrets=[]
for k,v in os.environ.items():
 if re.search(r'(TOKEN|KEY|SECRET|PASSWORD)',k,re.I) and len(v)>=8:secrets.append(v.encode())
def collect(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if isinstance(v,str) and re.fullmatch(r'(password|token|refresh_token|access_token|api_key|secret)',k,re.I) and len(v)>=8:secrets.append(v.encode())
   else:collect(v)
 elif isinstance(x,list):
  for v in x:collect(v)
for f in P.rglob('private*.json'):
 try:collect(json.loads(f.read_text()))
 except Exception:pass
for line in Path('/workspace/.setup/lingdoc/state/services.env').read_text().splitlines():
 if '=' in line:
  value=line.split('=',1)[1].strip().strip('\"\'')
  if len(value)>=8:secrets.append(value.encode())
manifest=[]
for name in sorted(names):
 assert 'private' not in name and not name.endswith('services.env')
 f=P/name;raw=f.read_bytes()
 if any(s in raw for s in secrets):raise RuntimeError('Credential detected in '+name)
 manifest.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
assert len(json.loads((P/'model-ledger.json.calls.json').read_text())['requests'])==6
meta={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':'lingdoc-t16-closeout-20260927-01','final_acceptance':'pending_gong','credential_scan':'passed: actual environment credentials, private account tokens and service secrets excluded','cloud_model_calls':6,'new_calls_failure_closeout':0,'previous_budget_call_overrun':1,'files':manifest}
(P/'MVP-验收包-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));names.add('MVP-验收包-manifest.json')
tmp=P/'LingDoc-MVP-验收证据-20261001.tmp.zip'
with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
 for n in sorted(names):z.write(P/n,n)
with zipfile.ZipFile(tmp) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
tmp.replace(target);sha=hashlib.sha256(target.read_bytes()).hexdigest();(P/(target.name+'.sha256')).write_text(sha+'  '+target.name+'\n');print('Final review pack verified:',len(names),'files',target.stat().st_size,'bytes; SHA256',sha)
