import asyncio,json,pathlib,urllib.parse,http.server,threading,zipfile
from playwright.async_api import async_playwright
P=pathlib.Path('/workspace/.acceptance/lingdoc-t16-closeout-20260927-01');D=P/'full-chain'
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(P),**kw)
 def do_GET(self):
  target=urllib.parse.unquote(urllib.parse.urlparse(self.path).path).lstrip('/')
  with zipfile.ZipFile(P/'LingDoc-MVP-验收证据-20261001.zip') as z:allowed=set(z.namelist())
  if target not in allowed:self.send_error(404);return
  super().do_GET()
 def log_message(self,*a):pass
async def main():
 errors=[]
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 async with async_playwright() as w:
  b=await w.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=await b.new_context(viewport={'width':1440,'height':1000},accept_downloads=True);page=await ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));await page.goto('http://127.0.0.1:'+str(server.server_port)+'/'+urllib.parse.quote('验收入口.html'));assert await page.locator('[data-task]').count()==16
  hrefs=await page.locator('a[href]').evaluate_all('(a)=>a.map(x=>x.getAttribute("href"))');missing=[h for h in hrefs if not (P/urllib.parse.unquote(h)).exists()];assert not missing,missing
  await page.wait_for_function('document.querySelector("video").readyState>=1');duration=await page.locator('video').evaluate('(v)=>v.duration');assert 35<duration<40,duration
  await page.locator('video').evaluate('(v)=>v.play()');await page.wait_for_function('document.querySelector("video").currentTime>0.1');await page.locator('video').evaluate('(v)=>v.pause()');await page.screenshot(path=str(D/'review-page.png'))
  for select in await page.locator('[data-task]').all():await select.select_option('accept_scope')
  await page.locator('#final').select_option('accept_mvp_scoped');await page.locator('#export').click();message=await page.locator('#message').inner_text();assert 'Office' in message and '范围取舍' in message
  await page.locator('#final').select_option('pending')
  async with page.expect_download() as info:await page.locator('#export').click()
  f=D/'test-only-draft-record.tmp';await (await info.value).save_as(str(f));record=json.loads(f.read_text());assert record['final_decision']=='pending' and record['unverified_conditions_remain_unverified'] is True;f.unlink();assert not errors
  await ctx.close();await b.close();server.shutdown();server.server_close();(D/'review-page-test.json').write_text(json.dumps({'scope':'Portable review HTML tested through ephemeral loopback HTTP (cloud Chromium blocks file URLs); simulated review fields are not gong feedback','task_rows':16,'video_duration_seconds':duration,'actual_video_playback_verified':True,'all_link_targets_exist':True,'acceptance_with_missing_office_evidence_rejected':True,'missing_scope_decision_rejected':True,'draft_record_download_verified':True,'simulated_download_removed':True,'page_errors':errors},ensure_ascii=False,indent=2));print('Offline review page: 16 tasks, links, guardrails and draft download PASS')
asyncio.run(main())
