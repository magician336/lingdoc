#!/usr/bin/env bash
set -euo pipefail
cd /workspace/lingdoc
export PATH=/workspace/.tools/go/bin:$PATH
export GOMODCACHE=/workspace/.cache/go-mod GOCACHE=/tmp/lingdoc-go-build CGO_CFLAGS=-I/workspace/.tools/native/usr/include
export LD_LIBRARY_PATH=/workspace/.tools/native/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
set -a
source /workspace/.setup/lingdoc/state/services.env
set +a
export DB_DRIVER=postgres DB_HOST=127.0.0.1 DB_PORT=5432 DB_USER=lingdoc DB_NAME=lingdoc_fault_http_20261001_01
export RETRIEVE_DRIVER=postgres STORAGE_TYPE=local LOCAL_STORAGE_BASE_DIR=/workspace/.acceptance/lingdoc-t16-closeout-20260927-01/files
export STREAM_MANAGER_TYPE=redis REDIS_ADDR=127.0.0.1:6379 REDIS_PASSWORD=
export DOCREADER_ADDR=127.0.0.1:50051 DOCREADER_TRANSPORT=grpc
export GIN_MODE=release AUTO_MIGRATE=true DUCKDB_SKIP_EXTENSION_LOAD=0
export OLLAMA_BASE_URL=http://127.0.0.1:11434 BUILTIN_MODELS_CONFIG=/workspace/.setup/lingdoc/builtin-models.yaml
export LINGDOC_T10_ACCEPTANCE_PROFILE=lingdoc-t10-deepseek-flash-20260929-v1
export LINGDOC_T10_ACCEPTANCE_LEDGER=/workspace/.acceptance/lingdoc-t16-closeout-20260927-01/model-ledger.json
export SERVER_PORT=8181 SERVER_HOST=127.0.0.1 REDIS_DB=15
exec /workspace/.acceptance/lingdoc-t16-closeout-20260927-01/server-mvp-integrity
