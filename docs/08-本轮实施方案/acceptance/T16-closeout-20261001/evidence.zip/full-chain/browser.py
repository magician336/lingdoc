import asyncio,json,pathlib,hashlib
from playwright.async_api import async_playwright
P=pathlib.Path('/workspace/.acceptance/lingdoc-t16-closeout-20260927-01');D=P/'full-chain';V=D/'videos';V.mkdir(exist_ok=True)
async def main():
 login=json.loads((P/'identity/private-login.json').read_text());events=[];errors=[]
 async with async_playwright() as w:
  b=await w.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=await b.new_context(viewport={'width':1440,'height':1000},accept_downloads=True,record_video_dir=str(V));page=await ctx.new_page()
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:events.append({'path':r.url.split('5173')[-1],'method':r.request.method,'status':r.status}) if '/api/v1/lingdoc/' in r.url else None)
  page.on('dialog',lambda d:asyncio.create_task(d.accept()))
  await page.goto('http://127.0.0.1:5173');await page.evaluate('d=>{for(const[k,v]of Object.entries({weknora_token:d.token,weknora_user:JSON.stringify(d.user),weknora_tenant:JSON.stringify(d.active_tenant),weknora_memberships:JSON.stringify(d.memberships),weknora_selected_tenant_id:"10003"}))localStorage.setItem(k,v)}',login)
  await page.goto('http://127.0.0.1:5173/platform/lingdoc');await page.wait_for_timeout(2500)
  if await page.get_by_text('跳过引导',exact=True).count():await page.get_by_text('跳过引导',exact=True).click()
  await page.get_by_text('T16 真实模型与来源全链路验收',exact=True).click();await page.wait_for_timeout(1800)
  if await page.get_by_text('跳过引导',exact=True).count():await page.get_by_text('跳过引导',exact=True).click()
  await page.locator('.chapter-tabs button').first.click();await page.locator('.candidate-list button').first.click();await page.get_by_role('button',name='查看引用 1 原文',exact=True).click();await page.locator('.source-context').wait_for();await page.screenshot(path=str(D/'01-real-source.png'),full_page=True)
  await page.get_by_role('button',name='采纳到本章',exact=True).click()
  async with page.expect_response(lambda r:'/acceptances' in r.url and r.request.method=='POST') as response:await page.get_by_role('button',name='确认整章替换',exact=True).click()
  r=await response.value;assert r.status==409,(r.status,await r.text());(D/'stale-adoption.json').write_text(json.dumps(await r.json(),ensure_ascii=False,indent=2));await page.screenshot(path=str(D/'02-stale-candidate-rejected.png'));await page.get_by_role('button',name='取消',exact=True).last.click()
  for i in range(2):
   await page.locator('.chapter-tabs button').nth(i).click();await page.wait_for_timeout(500)
   items=page.locator('.review-item')
   for n in range(await items.count()):
    await items.nth(n).locator('select').select_option('retained_warning');await items.nth(n).locator('textarea').fill('验收合成资料；相关事实与计划未独立核实，保留提示，不作为真实研究结论。')
   async with page.expect_response(lambda r:'/confirmations' in r.url and r.request.method=='POST') as response:await page.get_by_role('button',name='重新确认当前版本',exact=True).click()
   r=await response.value;assert r.status==201,(r.status,await r.text());(D/f'confirmation-{i+1}.json').write_text(json.dumps(await r.json(),ensure_ascii=False,indent=2));await page.wait_for_timeout(500);await page.screenshot(path=str(D/f'03-chapter-{i+1}-confirmed.png'),full_page=True)
  async with page.expect_response(lambda r:'/checks' in r.url and r.request.method=='POST') as response:await page.get_by_role('button',name='交付检查',exact=True).click()
  r=await response.value;assert r.status==200;(D/'check.json').write_text(json.dumps(await r.json(),ensure_ascii=False,indent=2))
  async with page.expect_response(lambda r:'/releases' in r.url and r.request.method=='POST') as response:await page.get_by_role('button',name='冻结当前内容',exact=True).click()
  r=await response.value;assert r.status==201;(D/'release.json').write_text(json.dumps(await r.json(),ensure_ascii=False,indent=2));await page.wait_for_timeout(700)
  buttons=page.get_by_role('button',name='生成 DOCX',exact=True);enabled=[]
  for i in range(await buttons.count()):
   if await buttons.nth(i).is_enabled():enabled.append(i)
  assert len(enabled)==1,enabled
  async with page.expect_response(lambda r:'/exports' in r.url and r.request.method=='POST') as response:await buttons.nth(enabled[0]).click()
  r=await response.value;assert r.status==202;(D/'export.json').write_text(json.dumps(await r.json(),ensure_ascii=False,indent=2));await page.wait_for_timeout(800)
  await page.locator('.delivery').scroll_into_view_if_needed();await page.screenshot(path=str(D/'04-current-download-history-disabled.png'),full_page=True)
  async with page.expect_download() as info:await page.get_by_role('button',name='下载 DOCX',exact=True).first.click()
  f=D/'browser-current-model.docx';await (await info.value).save_as(str(f));await page.wait_for_timeout(1200);video=page.video;await ctx.close();vp=await video.path();await b.close()
  assert not any(e['method']=='POST' and '/retrieval' in e['path'] for e in events);assert len(json.loads((P/'model-ledger.json.calls.json').read_text())['requests'])==6
  (D/'result.json').write_text(json.dumps({'scope':'existing real model candidates; browser provenance, stale rejection, two chapter review confirmations, check, freeze, export and download','browser':'system Chromium','video':vp,'file_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'page_errors':errors,'responses':events,'new_supplier_calls':0,'cloud_supplier_calls_total':6,'historical_export_buttons_disabled':awaitable_placeholder if False else len(enabled)==1},ensure_ascii=False,indent=2));print('Full browser continuation PASS',flush=True)
asyncio.run(main())
