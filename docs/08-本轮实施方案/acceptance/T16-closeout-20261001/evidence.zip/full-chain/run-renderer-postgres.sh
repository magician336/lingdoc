#!/usr/bin/env bash
set -euo pipefail
cd /workspace/lingdoc
source /workspace/.setup/lingdoc/activate.sh
set -a
source /workspace/.setup/lingdoc/state/services.env
set +a
export LINGDOC_FAILURE_TEST_DB=lingdoc_fault_renderer_20261001_01
compose=(docker compose --project-name lingdoc --env-file /workspace/.setup/lingdoc/state/services.env -f /workspace/.setup/lingdoc/compose.yaml)
# Fail if this dedicated name already exists; never reuse the product database.
"${compose[@]}" exec -T postgres psql -U lingdoc -d postgres -v ON_ERROR_STOP=1 -c "CREATE DATABASE $LINGDOC_FAILURE_TEST_DB"
cleanup() { "${compose[@]}" exec -T postgres psql -U lingdoc -d postgres -v ON_ERROR_STOP=1 -c "DROP DATABASE $LINGDOC_FAILURE_TEST_DB"; }
trap cleanup EXIT
for migration in 000097_lingdoc_workspace 000099_lingdoc_candidate_adoption 000100_lingdoc_generation_runs 000101_lingdoc_generation_claim_token 000103_lingdoc_delivery_stores; do
 "${compose[@]}" exec -T postgres psql -U lingdoc -d "$LINGDOC_FAILURE_TEST_DB" -v ON_ERROR_STOP=1 < "migrations/versioned/$migration.up.sql"
done
go test -v ./internal/lingdoc/workspace -run "^TestPostgresRendererFailureUsesRealDOCXValidator$" -count=1
